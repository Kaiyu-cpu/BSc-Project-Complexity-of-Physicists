*[[Jules Aarons]] – United States (1921–2016)
*[[Ernst Karl Abbe]] – Germany (1840–1905)
*[[Derek Abbott]] – Australia (born 1960)
*[[Hasan Abdullayev]] – Azerbaijan Democratic Republic, Soviet Union, Azerbaijan (1918–1993)
*[[Alexei Alexeyevich Abrikosov]] – Soviet Union, Russia (1928–2017) Nobel laureate
*[[Robert Adler]] – United States (1913–2007)
*[[Stephen L. Adler]] – United States (born 1939)
*[[Franz Aepinus]] – Rostock (1724–1802)
*[[David Z Albert]] – United States (born 1954)
*[[Felicie Albert]] – France, United States
*[[Miguel Alcubierre]] – Mexico (born 1964)
*[[Zhores Ivanovich Alferov]] – Russia (1930–2019) Nobel laureate
*[[Hannes Olof Gösta Alfvén]] – Sweden (1908–1995) Nobel laureate
*[[Alhazen]] – Basra, Iraq (965–1040)
*[[Artem Alikhanian]] – Armenia (1908–1978)
*[[Abram Alikhanov]] – Russia (1904–1970)
*[[William Allis]] – United States (1901–1999)
*[[Samuel King Allison]] – United States (1900–1965)
*[[Yakov Lvovich Alpert]] – Russia, United States (1911–2010)
*[[Ralph Asher Alpher]] – United States (1921–2007)
*[[Semen Altshuler]] – Vitebsk (1911–1983)
*[[Luis Walter Alvarez]] – United States (1911–1988) Nobel laureate
*[[Viktor Ambartsumian]] – Soviet Union, Armenia (1908–1996)
*[[André-Marie Ampère]] – France (1775–1836)
*[[Anja Cetti Andersen]] – Denmark (born 1965)
*[[Hans Henrik Andersen]] – Denmark (1937–2012)
*[[Philip Warren Anderson]] – United States (1923–2020) Nobel laureate
*[[Carl David Anderson]] – United States (1905–1991) Nobel laureate
*[[Herbert L. Anderson]] – United States (1914–1988)
*[[Elephter Andronikashvili]] – Georgia (1910–1989)
*[[Anders Jonas Ångström]] – Sweden (1814–1874)
*[[Alexander Animalu]], Nigeria (born 1938)
*[[Edward Victor Appleton]] – U.K. (1892–1965) Nobel laureate
*[[François Arago]] – France (1786–1853)
*[[Archimedes]] – Syracuse, Greece (ca. 287–212&amp;nbsp;BC)
*[[Manfred von Ardenne]] – Germany (1907–1997)
*[[Aristarchus of Samos]] – Samos, Greece (310–ca. 230&amp;nbsp;BC)
*[[Aristotle]] – Athens, Greece (384–322&amp;nbsp;BC)
*[[Nima Arkani-Hamed]] – United States (born 1972)
*[[Lev Artsimovich]] – Moscow (1909–1973)
*[[Aryabhata]] – Pataliputra, India (476–550)
*[[Neil Ashby]] – United States (born 1934)
*[[Maha Ashour-Abdalla]] – Egypt, United States (1943–2016)
*[[Gurgen Askaryan]] – Soviet Union (1928–1997)
*[[Alain Aspect]] – France (born 1947)
*[[Marcel Audiffren]] – France
*[[Avicenna]] – Persia (980–1037)
*[[Amedeo Avogadro]] – Italy (1776–1856)
*[[David Awschalom]] – United States (born 1956)
*[[A. P. J. Abdul Kalam|APJ Abdul Kalam]] – India
*[[Xiaoyi Bao]] – Canada
*[[Mani Lal Bhaumik]] – United States (born 1931)
*[[Tom Baehr-Jones]] – United States (born 1980)
*[[Gilbert Ronald Bainbridge]] – U.K. (1925–2003)
*[[Cornelis Bakker]] – Netherlands (1904–1960)
*[[Aiyalam Parameswaran Balachandran]] – India (born 1938)
*[[V. Balakrishnan (physicist)|V Balakrishnan]] – India (born 1943)
*[[Milla Baldo-Ceolin]] – Italy (1924–2011)
*[[Johann Jakob Balmer]] – Switzerland (1825–1898)
*[[Tom Banks (physicist)|Tom Banks]] – United States (born 1949)
*[[Riccardo Barbieri]] – Italy (born 1944)
*[[Marcia Barbosa]] – Brazil (born 1960)
*[[John Bardeen]] – United States (1908–1991) double Nobel laureate
*[[William A. Bardeen]] – United States (born 1941)
*[[Charles Glover Barkla]] – U.K. (1877–1944) Nobel laureate
*[[Amanda Barnard]] – Australia (born 1971)
*[[Boyd Bartlett]] – United States (1897–1965)
*[[Asım Orhan Barut]] – Malatya, Turkey (1926–1994)
*[[Heinz Barwich]] – Germany (1911–1966)
*[[Nikolay Basov]] – Russia (1922–2001) Nobel laureate
*[[Laura Maria Caterina Bassi]] – Italy (1711–1778)
*[[Zoltán Lajos Bay]] – Hungary (1900–1992)
*[[Karl Bechert]] – Germany (1901–1981)
*[[Henri Becquerel]] – France (1852–1908) Nobel laureate
*[[Johannes Georg Bednorz]] – Germany (born 1950) Nobel laureate
*[[Isaac Beeckman]] – Netherlands (1588–1637)
*[[Alexander Graham Bell]] – Scotland, Canada, U.S.A. (1847–1922)
*[[John Stewart Bell]] – U.K. (1928–1990)
*[[Jocelyn Bell Burnell]] – Northern Ireland, U.K. (born 1943)
*[[Carl M. Bender]] – United States (born 1943)
*[[Abraham Bennet]] – England (1749–1799)
*[[Daniel Bernoulli]] – Switzerland (1700–1782)
*[[Hans Bethe]] – Germany, United States (1906–2005) Nobel laureate
*[[Homi J. Bhabha]] – India (1909–1966)
*[[Lars Bildsten]] – United States (1964)
*[[James Binney]] – England (born 1950)
*[[Gerd Binnig]] – Germany (born 1947) Nobel laureate
*[[Jean-Baptiste Biot]] – France (1774–1862)
*[[Raymond T. Birge]] – United States (1887–1980)
*[[Abū Rayhān al-Bīrūnī]] – Persia (973–1048)
*[[Vilhelm Bjerknes]] – Norway (1862–1951)
*[[James Bjorken]] – United States (born 1934)
*[[Patrick Blackett]] – U.K. (1897–1974) Nobel laureate
*[[Felix Bloch]] – Switzerland (1905–1983) Nobel laureate
*[[Nicolaas Bloembergen]] – Netherlands, United States (1920–2017) Nobel laureate
*[[Walter Boas]] – Germany, Australia (1904–1982)
*[[Céline Bœhm]] – France (born 1974)
*[[Nikolay Bogolyubov]] – Soviet Union, Russia (1909–1992)
*[[David Bohm]] – United States (1917–1992)
*[[Aage Bohr]] – Denmark (1922–2009) Nobel laureate
*[[Niels Bohr]] – Denmark (1885–1962) Nobel laureate
*[[Martin Bojowald]] – Germany (born 1973)
*[[Ludwig Boltzmann]] – Austria (1844–1906)
*[[Eugene T. Booth]] – United States (1912–2004)
*[[Max Born]] – Germany, U.K. (1882–1970) Nobel laureate
*[[Rudjer Josip Boscovich]] – Croatia (1711–1787)
*[[Jagadish Chandra Bose]] – India (1858–1937)
*[[Margrete Heiberg Bose]] – Denmark (1866–1952)
*[[Satyendra Nath Bose]] – India (1894–1974)
*[[Johannes Bosscha]] – Netherlands (1831–1911)
*[[Walther Bothe]] – Germany (1891–1957) Nobel laureate
*[[Edward Bouchet]] – United States (1852–1918)
*[[Mark Bowick]] – United States (born 1957)
*[[Robert Boyle]] – Ireland, England (1627–1691)
*[[Willard Boyle|Willard S. Boyle]] – Canada, United States (1924–2011) Nobel laureate
*[[William Henry Bragg]] – U.K. (1862–1942) Nobel laureate
*[[William Lawrence Bragg]] – U.K., Australia (1890–1971) Nobel laureate
*[[Tycho Brahe]] – Denmark (1546–1601)
*[[Howard Brandt]] – United States (1939–2014)
*[[Walter Houser Brattain]] – United States (1902–1987) Nobel laureate
*[[Karl Ferdinand Braun]] – Germany (1850–1918) Nobel laureate
*[[David Brewster]] – U.K. (1781–1868)
*[[Percy Williams Bridgman]] – United States (1882–1961) Nobel laureate
*[[Léon Brillouin|Léon Nicolas Brillouin]] – France (1889–1969)
*[[Marcel Brillouin]] – France (1854–1948)
*[[Bertram Brockhouse]] – Canada (1918–2003) Nobel laureate
*[[Louis-Victor de Broglie]] – France (1892–1987) Nobel laureate
*[[William Fuller Brown, Jr.]] – United States (1904–1983)
*[[Ernst Brüche]] – Germany (1900–1985)
*[[Hermann Brück]] – Germany (1905–2000)
*[[Ari Brynjolfsson]] – Iceland (1927–2013)
*[[Hans Buchdahl]] – Germany, Australia (1918–2010)
*[[Gersh Budker]] – Soviet Union (1918–1977)
*[[Silke Bühler-Paschen]] – Austria (born 1967)
*[[Johannes Martinus Burgers]] – Netherlands (1895–1981)
*[[Friedrich Burmeister]] – Germany (1890–1969)
*[[Bimla Buti]] – India (born 1933)
*[[C.H.D. Buys Ballot|Christophorus Buys Ballot]] – Netherlands (1817–1890)
*[[Nicola Cabibbo]] – Italy (1935–2010)
*[[Nicolás Cabrera]] – Spain (1913–1989)
*[[Orion Ciftja]] - United States
*[[Curtis Callan]] – United States (born 1942)
*[[Annie Jump Cannon]] – United States (1863–1941)
*[[Fritjof Capra]] – Austria, United States (born 1939)
*[[Marcela Carena]] – Argentina (born 1962)
*[[Ricardo Carezani]] – Argentina, United States (born 1921)
*[[Nicolas Léonard Sadi Carnot]] – France (1796–1832)
*[[David Carroll (physicist)|David Carroll]] – United States (born 1963)
*[[Brandon Carter]] – Australia (born 1942)
*[[Hendrik Casimir]] – Netherlands (1909–2000)
*[[Henry Cavendish]] – U.K. (1731–1810)
*[[James Chadwick]] – U.K. (1891–1974) Nobel laureate
*[[Owen Chamberlain]] – United States (1920–2006) Nobel laureate
*[[Moses H. W. Chan]] – Hong Kong (born 1946)
*[[Subrahmanyan Chandrasekhar]] – India, United States (1910–1995) Nobel laureate
*[[Georges Charpak]] – France (1924–2010) Nobel laureate
*[[Émilie du Châtelet]] – France (1706–1749)
*[[Swapan Chattopadhyay]] – India (born 1951)
*[[Pavel Alekseyevich Cherenkov]] – Imperial Russia, Soviet Union (1904–1990) Nobel laureate
*[[Maxim Chernodub]] – Russia, France (born 1973)
*[[Geoffrey Chew]] – United States (1924–2019)
*[[Boris Chirikov]] – Soviet Union, Russia (1928–2008)
*[[Juansher Chkareuli]] – Georgia (born 1940)
*[[Ernst Chladni]] – Germany (1756–1827)
*[[Steven Chu]] – United States (born 1948) Nobel laureate
*[[Giovanni Ciccotti]] – Italy (born 1943)
*[[Benoît Paul Émile Clapeyron|Benoît Clapeyron]] – France (1799–1864)
*[[George W. Clark]] – United States
*[[Rudolf Clausius]] – Germany (1822–1888)
*[[Gerald B. Cleaver]] – United States
*[[Richard Clegg]] – United Kingdom
*[[Gari Clifford]] - British-American physicist, biomedical engineer, academic, researcher
*[[John Cockcroft]] – United Kingdom (1897–1967) Nobel laureate
*[[Claude Cohen-Tannoudji]] – France (born 1933) Nobel laureate
*[[Arthur Compton]] – United States (1892–1962) Nobel laureate
*[[Karl Compton]] – United States (1887–1954)
*[[Edward Condon]] – United States (1902–1974)
*[[Leon Cooper]] – United States (born 1930) Nobel laureate
*[[Alejandro Corichi]] – Mexico (born 1967)
*[[Gaspard-Gustave Coriolis]] – France (1792–1843)
*[[Allan McLeod Cormack]] – South Africa, United States (1924–1998)
*[[Eric Allin Cornell]] – United States (born 1961) Nobel laureate
*[[Marie Alfred Cornu]] – France (1841–1902)
*[[Charles-Augustin de Coulomb]] – France (1736–1806)
*[[Ernest Courant]] – United States (born 1920)
*[[Brian Cox (physicist)|Brian Cox]] – U.K. (born 1968)
*[[Charles Critchfield]] – United States (1910–1994)
*[[James Cronin]] – United States (1931–2016) Nobel laureate
*[[Sir William Crookes]] – U.K. (1832–1919)
*[[Paul Crowell]] – United States
*[[Marie Curie]] – Poland, France (1867–1934) twice Nobel laureate
*[[Pierre Curie]] – France (1859–1906) Nobel laureate
*[[Predrag Cvitanović]] – Croatia (born 1946)
*[[Jean le Rond d'Alembert]] – France (1717–1783)
*[[Gustaf Dalén]] – Sweden (1869–1937) Nobel laureate
*[[Jean Dalibard]] – France (born 1958)
*[[Richard Dalitz]] – U.K., United States (1925–2006)
*[[John Dalton]] – U.K. (1766–1844)
*[[Sanja Damjanović]] – Montenegro (born 1972)
*[[Ranjan Roy Daniel]] – India (1923–2005)
*[[Charles Galton Darwin]] – U.K. (1887–1962)
*[[Ashok Das]] – India, United States (born 1953)
*[[James C. Davenport]] – United States (born 1938)
*[[Paul Davies]] – Australia (born 1946)
*[[Raymond Davis, Jr.]] – United States (1914–2006) Nobel laureate
*[[Clinton Davisson]] – United States (1881–1958) Nobel laureate
*[[Peter Debye|Peter Debije]] – Netherlands (1884–1966)
*[[Hans Georg Dehmelt]] – Germany, United States (1922–2017) Nobel laureate
*[[Max Delbrück]] – Germany, United States (1906–1981)
*[[Democritus]] – Abdera (ca. 460–360 BC)
*[[David M. Dennison]] – United States (1900–1976)
*[[Beryl May Dent]] – U.K. (1900–1977)
*[[David Deutsch]] – Israel, U.K. (born 1953)
*[[James Dewar]] – U.K. (1842–1923)
*[[Scott Diddams]] – United States 
*[[Ulrike Diebold]] – Austria (born 1961)
*[[Robbert Dijkgraaf]] – Netherlands (born 1960)
*[[Viktor Dilman]] – Russia (born 1926)
*[[Savas Dimopoulos]] – United States (born 1952)
*[[Paul Dirac]] – Switzerland, U.K. (1902–1984) Nobel laureate
*[[Revaz Dogonadze]] – Soviet Union, Georgia (1931–1985)
*[[Amos Dolbear]] – United States (1837–1910)
*[[Robert Döpel]] – Germany (1895–1982)
*[[Christian Doppler]] – Austria (1803–1853)
*[[Henk Dorgelo]] – Netherlands (1894–1961)
*[[Friedrich Ernst Dorn]] – Germany (1848–1916)
*[[Michael R. Douglas]] – United States (born 1961)
*[[Jonathan Dowling]] – United States (born 1955)
*[[Claudia Draxl]] – Germany (born 1959)
*[[Sidney Drell]] – United States (1926–2016)
*[[Mildred Dresselhaus]] – United States (1930–2017)
*[[Paul Drude]] – Germany (1863–1906)
*[[F. J. Duarte]] – United States (born 1954)
*[[Émilie du Châtelet]] – France (1706–1749)
*[[Pierre Louis Dulong]] – France (1785–1838)
*[[Janette Dunlop]] – Scotland (1891–1971) 
*[[Samuel T. Durrance]] – United States (born 1943)
*[[Freeman Dyson]] – U.K., United States (1923–2020) Wolf laureate
*[[Arthur Jeffrey Dempster]] – Canada (1886–1950)
*[[Joseph H. Eberly]] – United States (born 1935)
*[[William Eccles (physicist)|William Eccles]] – U.K. (1875–1966)
*[[Carl Eckart]] – United States (1902–1973)
*[[Arthur Stanley Eddington]] – U.K. (1882–1944)
*[[Paul Ehrenfest]] – Austria-Hungary, Netherlands (1880–1933)
*[[Felix Ehrenhaft]] – Austria-Hungary, United States (1879–1952)
*[[Manfred Eigen]] – Germany (1927–2019)
*[[Albert Einstein]] – Germany, Italy, Switzerland, United States (1879–1955) Nobel laureate
*[[Laura Eisenstein]] – (1942–1985) professor of physics at University of Illinois 
*[[Terence James Elkins]] – Australia, United States (born 1936)
*[[John Ellis (physicist)|John Ellis]] – U.K. (born 1946)
*[[Paul John Ellis]] – U.K., United States (1941–2005)
*[[Richard Keith Ellis]] – U.K., United States (born 1949)
*[[Arpad Elo]] – Hungary (1903–1992)
*[[François Englert]] – Belgium (born 1932) Nobel laureate
*[[David Enskog]] – Sweden (1884–1947)
*[[Loránd Eötvös]] – Austria-Hungary (1848–1919)
*[[Ernst equation|Frederick J. Ernst]] – United States (born 1933)
*[[Leo Esaki]] – Japan (born 1925) Nobel laureate
*[[Ernest Esclangon]] – France (1876–1954)
*[[Louis Essen]] – U.K. (1908–1997)
*[[Leonhard Euler]] – Switzerland (1707–1783)
*[[Denis Evans]] – Australia (born 1951)
*[[Paul Peter Ewald]] – Germany, United States (1888–1985)
*[[James Alfred Ewing]] – U.K. (1855–1935)
*[[Franz S. Exner]] – Austria (1849–1926)
*[[Ludvig Faddeev]] – Russia (1934–2017)
*[[Daniel Gabriel Fahrenheit]] – [[Royal Prussia|Prussia]] (1686–1736)
*[[Kazimierz Fajans]] – Poland, United States (1887–1975)
*[[James E. Faller]] – United States 
*[[Michael Faraday]] – U.K. (1791–1867)
*[[Eugene Feenberg]] – United States (1906–1977)
*[[Mitchell Feigenbaum]] – United States (1944–2019)
*[[Gerald Feinberg]] – United States (1933–1992)
*[[Enrico Fermi]] – Italy (1901–1954) Nobel laureate
*[[Albert Fert]] – France (born 1938) Nobel laureate
*[[Herman Feshbach]] – United States (1917–2000)
*[[Richard Feynman]] – United States (1918–1988) Nobel laureate
*[[Wolfgang Finkelnburg]] – Germany (1905–1967)
*[[David Finkelstein]] – United States (1929–2016)
*[[Johannes Fischer]] – Germany (born 1887)
*[[Willy Fischler]]  – Belgium (born 1949)
*[[Val Logsdon Fitch]] – United States (1923–2015) Nobel laureate
*[[George Francis FitzGerald]] – Ireland (1851–1901)
*[[Hippolyte Fizeau]] – France (1819–1896)
*[[Georgy Flyorov]] – Rostov-on-Don (1913–1990)
*[[Vladimir Fock]] – Imperial Russia, Soviet Union (1898–1974)
*[[Adriaan Fokker]] – Netherlands (1887–1972)
*[[Arthur Foley]] – America (1867–1945)
*[[James David Forbes]] – U.K. (1809–1868)
*[[Jeff Forshaw]] – U.K. (born 1968) 
*[[Léon Foucault]] – France (1819–1868)
*[[Joseph Fourier]] – France (1768–1830)
*[[Ralph H. Fowler]] – U.K. (1889–1944)
*[[William Alfred Fowler]] – United States (1911–1995) Nobel laureate
*[[James Franck]] – Germany, United States (1882–1964) Nobel laureate
*[[Ilya Frank]] – Soviet Union (1908–1990) Nobel laureate
*[[Benjamin Franklin]] – British America, United States (1706–1790)
*[[Rosalind Franklin]] – U.K. (1920–1958)
*[[Walter Franz]] – Germany (1911–1992)
*[[Joseph von Fraunhofer]] – Germany (1787–1826)
*[[Steven Frautschi]] – United States (born 1933)
*[[Joan Maie Freeman]] – Australia (1918–1998)
*[[Phyllis S. Freier]] – United States (1921–1992))
*[[Yakov Frenkel]] – Imperial Russia, Soviet Union (1894–1952)
*[[Augustin-Jean Fresnel]] – France (1788–1827)
*[[Peter Freund]] – United States (1936–2018)
*[[Daniel Friedan]] – United States (born 1948)
*[[B. Roy Frieden]] – United States (born 1936)
*[[Alexander Friedman]] – Imperial Russia, Soviet Union (1888–1925)
*[[Jerome Isaac Friedman]] – United States (born 1930) Nobel laureate
*[[Otto Frisch]] – Austria, U.K. (1904–1979)
*[[Erwin Fues]] – Germany (1893–1970)
*[[Harald Fuchs]] – Germany (born 1951)
*[[Dennis Gabor]] – Hungary (1900–1979) Nobel laureate
*[[Mary K. Gaillard]] – France, United States (born 1939)
*[[Galileo Galilei]] – Italy (1564–1642)
*[[Luigi Galvani]] – Italy (1737–1798)
*[[George Gamow]] – Russia, United States (1904–1968)
*[[Sylvester James Gates]] – United States (born 1950)
*[[Carl Friedrich Gauss]] – Germany (1777–1855)
*[[Pamela L. Gay]] – United States (born 1973)
*[[Joseph Louis Gay-Lussac]] – France (1778–1850)
*[[Hans Geiger]] – Germany (1882–1945)
*[[Andre Geim]] – Russian/British (born 1958) Nobel laureate
*[[Murray Gell-Mann]] – United States (1929–2019) Nobel laureate
*[[Pierre-Gilles de Gennes]] – France (1932–2007) Nobel laureate
*[[Howard Georgi]] – United States (born 1947)
*[[Walter Gerlach]] – Germany (1889–1979)
*[[Christian Gerthsen]] – Denmark, Germany (1894–1956)
*[[Ezra Getzler]] – Australia (born 1962)
*[[Andrea M. Ghez]] – United States (born 1955) Nobel laureate
*[[Riccardo Giacconi]] – Italy, United States (1931–2018) Nobel laureate
*[[Ivar Giaever]] – Norway, United States (born 1929) Nobel laureate
*[[Josiah Willard Gibbs]] – United States (1839–1903)
*[[Valerie Gibson]] – U.K. (born 19??)
*[[William Gilbert (astronomer)|William Gilbert]] – England (1544–1603)
*[[Piara Singh Gill]] – India (1911–2002)
*[[Naomi Ginsberg]] – United States (born 1979)
*[[Vitaly Ginzburg|Vitaly Lazarevich Ginzburg]] – Soviet Union, Russia (1916–2009) Nobel laureate
*[[Marvin D. Girardeau]] – United States (1930–2015)
*[[Donald A. Glaser|Donald Arthur Glaser]] – United States (1926–2013) Nobel laureate
*[[Sheldon Lee Glashow]] – United States (born 1932) Nobel laureate
*[[G. N. Glasoe]] – United States (1902–1987)
*[[Roy J. Glauber|Roy Jay Glauber]] – United States (1925–2018) Nobel laureate
*[[James Glimm]] – United States (born 1934)
*[[Karl Glitscher]] – Germany (1886–1945)
*[[Peter Goddard (physicist)|Peter Goddard]] – U.K. (born 1945)
*[[Maria Goeppert-Mayer]] – Germany, United States (1906–1972) Nobel laureate
*[[Gerald Goertzel]] – United States (1920–2002)
*[[Marvin Leonard Goldberger]] – United States (1922–2014)
*[[Maurice Goldhaber]] – Austria, United States (1911–2011)
*[[Jeffrey Goldstone]] – U.K., United States (born 1933)
*[[Sixto González]] – Puerto Rico, United States (born 1965)
*[[Ravi Gomatam]] – India (born 1950)
*[[Lev Gor'kov]] – United States (1929–2016)
*[[Samuel Goudsmit]] – Netherlands, United States (1902–1978)
*[[Leo Graetz]] – Germany (1856–1941)
*[[Willem 's Gravesande]] – Netherlands (1688–1742)
*[[Michael Green (physicist)]] – Britain (born 1946)
*[[Daniel Greenberger]] – United States (born 1932)
*[[Brian Greene]] – United States (born 1963)
*[[John Gribbin]] – U.K. (born 1946)
*[[Vladimir Gribov]] – Russia (1930–1997)
*[[David J. Griffiths]] – United States (born 1942)
*[[David Gross]] – United States (born 1941) Nobel laureate
*[[Frederick Grover]] – United States (1876–1973)
*[[Peter Grünberg]] – Germany (1939–2018) Nobel laureate
*[[Charles Edouard Guillaume|Charles Édouard Guillaume]] – Switzerland (1861–1931) Nobel laureate
*[[Ayyub Guliyev]] – Azerbaijan (born 1954)
*[[Feza Gürsey]] – Turkey (1921–1992)
*[[Alan Guth]] – United States (born 1947)
*[[Martin Gutzwiller]] – Switzerland (1925–2014)
*[[Rudolf Haag]] – Germany (1922–2016)
*[[Wander Johannes de Haas]] – Netherlands (1878–1960)
*[[Alain Haché]] – Canada (born 1970)
*[[Carl Richard Hagen]] – United States (born 1937)
*[[Otto Hahn]] – Germany (1879–1968)
*[[Edwin Hall]] – United States (1855–1938)
*[[John L. Hall|John Lewis Hall]] – United States (born 1934) Nobel laureate
*[[Alexander_R._Hamilton|Alexander Hamilton]] – UK, Australia (born 1967)
*[[William Rowan Hamilton]] – Ireland (1805–1865)
*[[Theodor W. Hänsch|Theodor Wolfgang Hänsch]] – Germany (born 1941) Nobel laureate
*[[Peter Andreas Hansen]] – Denmark (1795–1874)
*[[W.W. Hansen]] – United States (1909–1949)
*[[Serge Haroche]] – France (born 1944) Nobel laureate
*[[Paul Harteck]] – Germany (1902–1985)
*[[John Hartnett (physicist)|John G. Hartnett]] – Australia (born 1952)
*[[Douglas Hartree]] – U.K. (1897–1958)
*[[Friedrich Hasenöhrl]] – Austria, Hungary (1874–1915)
*[[Lene Vestergaard Hau]] – Vejle, Denmark (born 1959)
*[[Stephen Hawking]] – U.K. (1942–2018) Wolf laureate
*[[Ibn al-Haytham]] – Iraq (965–1039)
*[[Evans Hayward]] – United States (born 1922)
*[[Oliver Heaviside]] – U.K. (1850–1925)
*[[Werner Heisenberg]] – Germany (1901–1976) Nobel laureate
*[[Walter Heitler]] – Germany, Ireland (1904–1981)
*[[Hermann von Helmholtz]] – Germany (1821–1894)
*[[Charles H. Henry]] – United States (1937–2016)
*[[Joseph Henry]] – United States (1797–1878)
*[[John Herapath]] – U.K. (1790–1868)
*[[Carl Hermann]] – Germany (1898–1961)
*[[Gustav Ludwig Hertz]] – Germany (1887–1975) Nobel laureate
*[[Heinrich Rudolf Hertz]] – Germany (1857–1894)
*[[Karl Herzfeld]] – Austria, United States (1892–1978)
*[[Victor Francis Hess]] – Austria, United States (1883–1964) Nobel laureate
*[[Mahmoud Hessaby]] – Iran (1903–1992)
*[[Antony Hewish]] – U.K. (1924–2021) Nobel laureate
*[[Paul G. Hewitt]] – United States (born 1931)
*[[Peter Higgs]] – U.K. (born 1929) Nobel laureate
*[[George William Hill]] – United States (1838–1914)
*[[Gustave-Adolphe Hirn]] – France (1815–1890)
*[[Carol Hirschmugl]] -  United States, professor of physics, laboratory director
*[[Dorothy Crowfoot Hodgkin]] – England (1910–1994)
*[[Robert Hofstadter]] – United States (1915–1990) Nobel laureate
*[[Helmut Hönl]] – Germany (1903–1981)
*[[Pervez Hoodbhoy]] – Pakistan (born 1950)
*[[Gerardus 't Hooft]] – Netherlands (born 1946) Nobel laureate
*[[Robert Hooke]] – England (1635–1703)
*[[John Hopkinson]] – United Kingdom (1849–1898)
*[[Johann Baptiste Horvath]] – Slovakia (1732–1799)
*[[William V. Houston]] – United States (1900–1968)
*[[Charlotte Riefenstahl|Charlotte (née Riefenstahl) Houtermans]] – Germany (1899–1993)
*[[Fritz Houtermans]] – Netherlands, Germany, Austria (1903–1966)
*[[Archibald Howie]] – U.K. (born 1934)
*[[Fred Hoyle]] – U.K. (1915–2001)
*[[John Hubbard (physicist)|John Hubbard]] – U.K. (1931–1980)
*[[John H. Hubbell]] – United States (1925–2007)
*[[Edwin Powell Hubble]] – United States (1889–1953)
*[[Russell Alan Hulse]] – United States (born 1950) Nobel laureate
*[[Friedrich Hund]] – Germany (1896–1997)
*[[Tahir Hussain (physicist)|Tahir Hussain]] – Pakistan (1923–2010)
*[[Andrew D. Huxley]] – U.K. (born 1966)
*[[Christiaan Huygens]] – Netherlands (1629–1695)
*[[Arthur Iberall]] – United States (1918–2002)
*[[Sumio Iijima]] – Japan (born 1939)
*[[John Iliopoulos]] – Greece (born 1940)
*[[Ataç İmamoğlu]] – Turkey, United States (born 1962)
*[[Elmer Imes]] – United States (1883–1941)
*[[Abram Ioffe]] – Russia (1880–1960)
*[[Nathan Isgur]] – United States, Canada (1947–2001)
*[[Ernst Ising]] – Germany (1900–1998)
*[[Jamal Nazrul Islam]] – Bangladesh (1939–2013)
*[[Werner Israel]] – Canada (born 1931)
*[[Roman Jackiw]] – Poland, United States (born 1939)
*[[Shirley Ann Jackson]] – United States (born 1946)
*[[Boris Jacobi]] – Germany, Russia (1801–1874)
*[[Gregory Jaczko]] – United States (born 1970)
*[[Chennupati Jagadish]] – India, Australia (born 1957)
*[[Jainendra Jain]] – India (born 1960)
*[[Ratko Janev]] – North Macedonia (1939–2019)
*[[Andreas Jaszlinszky]] – Hungary (1715–1783)
*[[Ali Javan]] – Iran (1928–2016)
*[[Edwin Thompson Jaynes|Edwin Jaynes]] – United States (1922–1998)
*[[Antal Jákli| Antal István Jákli]] – Hungary (born 1958)
*[[James Hopwood Jeans|Sir James Jeans]] – UK (1877–1946)
*[[J. Hans D. Jensen|Johannes Hans Daniel Jensen]] – Germany (1907–1973) Nobel laureate
*[[Deborah S. Jin]] – United States (born 1968)
*[[Anthony M. Johnson]] – United States (born 1954)
*[[Irène Joliot-Curie]] – France (1897–1956)
*[[Lorella Jones]] – United States (1943–1995)
*[[Pascual Jordan]] – Germany (1902–1980)
*[[Vania Jordanova]] - United States
*[[Brian David Josephson]] – UK (born 1940) Nobel laureate
*[[James Prescott Joule]] – UK (1818–1889)
*[[Adolfas Jucys]] – Lithuania (1904–1974)
*[[Chang Kee Jung]] – South Korea, United States
*[[Menas Kafatos]] – Greece, United States (born 1945)
*[[Takaaki Kajita]] – Japan (born 1959) Nobel laureate
*[[Michio Kaku]] – United States (born 1947)
*[[Theodor Kaluza]] – Germany (1885–1954)
*[[Heike Kamerlingh Onnes]] – Netherlands (1853–1926) Nobel laureate
*[[William R. Kanne]] – United States
*[[Charles K. Kao]] – China, Hong Kong, U.K., United States (1933–2018) Nobel laureate
*[[Pyotr Kapitsa]] – Russian Empire, Soviet Union (1894–1984) Nobel laureate
*[[Theodore von Kármán]] – Hungary, United States (1881–1963) aeronautical engineer
*[[Alfred Kastler]] – France (1902–1984) Nobel laureate
*[[Amrom Harry Katz]] – United States (1915–1997)
*[[Moshe Kaveh]] – Israel (born 1943) President of [[Bar-Ilan University]]
*[[Predhiman Krishan Kaw]] – India (1948–2017)
*[[Heinrich Kayser]] – Germany (1853–1940)
*[[Willem Hendrik Keesom]] – Netherlands (1876–1956)
*[[Edwin C. Kemble]] – United States (1889–1984)
*[[Henry Way Kendall]] – United States (1926–1999) Nobel laureate
*[[Johannes Kepler]] – Germany (1571–1630)
*[[John Kerr (physicist)|John Kerr]] – Scotland (1824–1907)
*[[Wolfgang Ketterle]] – Germany (born 1957) Nobel laureate
*[[Isaak Markovich Khalatnikov]] – Soviet Union (1919–2021)
*[[Jim Al-Khalili]] – UK (born 1962)
*[[Abdul Qadeer Khan]] – Pakistan (born 1936)
*[[Yulii Borisovich Khariton]] – Soviet Union, Russia (1904–1996)
*[[Erhard Kietz]] – Germany, United States (1909–1982)
*[[Jack Kilby]] – United States (1923–2005) electronics engineer, Nobel laureate
*[[Toichiro Kinoshita]] – Japan, United States (born 1925)
*[[Gustav Kirchhoff]] – Germany (1824–1887)
*[[Oskar Klein]] – Sweden (1894–1977)
*[[Hagen Kleinert]] – Germany (born 1941)
*[[Klaus von Klitzing]] – Germany (born 1943) Nobel laureate
*[[Jens Martin Knudsen]] – Denmark (1930–2005)
*[[Martin Knudsen]] – Denmark (1871–1949)
*[[Makoto Kobayashi (physicist)|Makoto Kobayashi]] – Japan (born 1944) Nobel laureate
*[[Arthur Korn]] – Germany (1870–1945)
*[[Masatoshi Koshiba]] – Japan (1926–2020) Nobel laureate
*[[Matthew Koss]] – United States (born 1961)
*[[Walther Kossel]] – Germany (1888–1956)
*[[Ashutosh Kotwal]] – United States (born 1965)
*[[Lew Kowarski]] – France (1907–1979)
*[[Hendrik Kramers]] – Netherlands (1894–1952)
*[[Serguei Krasnikov]] – Russia (born 1961)
*[[Adolf Kratzer]] – Germany (1893–1983)
*[[Lawrence M. Krauss]] – United States (born 1954)
*[[Herbert Kroemer]] – Germany (born 1928) Nobel laureate
*[[August Krönig]] – Germany (1822–1879)
*[[Ralph Kronig]] – Germany, United States (1904–1995)
*[[Nikolay Sergeevich Krylov]] – Soviet Union (1917–1947)
*[[Ryogo Kubo]] – Japan (1920–1995)
*[[Daya Shankar Kulshreshtha]] – India (born 1951) 
*[[Igor Vasilyevich Kurchatov]] – Soviet Union (1903–1960)
*[[Behram Kursunoglu]] – Turkey (1922–2003)
*[[Polykarp Kusch]] – Germany (1911–1993) Nobel laureate
*[[James W. LaBelle]] – United States
*[[Joseph Louis Lagrange|Joseph-Louis Lagrange]] – France (1736–1813)
*[[Willis Lamb]] – United States (1913–2008) Nobel laureate
*[[Lev Davidovich Landau]] – Imperial Russia, Soviet Union (1908–1968) Nobel laureate
*[[Rolf Landauer]] – United States (1927–1999)
*[[Grigory Landsberg]] – Vologda (1890–1957)
*[[Kenneth Lane (physicist)|Kenneth Lane]] – United States
*[[Paul Langevin]] – France (1872–1946)
*[[Irving Langmuir]] – United States (1881–1957)
*[[Pierre-Simon Laplace]] – France (1749–1827)
*[[Joseph Larmor]] – U.K. (1857–1942)
*[[Cesar Lattes]] – Brazil (1924–2005)
*[[Max von Laue]] – Germany (1879–1960) Nobel laureate
*[[Robert B. Laughlin|Robert Betts Laughlin]] – United States (born 1950) Nobel laureate
*[[Mikhail Lavrentyev]] – Kazan (1900–1980)
*[[Melvin Lax]] – United States (1922–2002)
*[[Ernest Lawrence]] – United States (1901–1958) Nobel laureate
*[[T._H._Laby|TH Laby]] – Australia (1880–1946)
*[[Pyotr Nikolaevich Lebedev]] – Imperial Russia (1866–1912)
*[[Leon M. Lederman|Leon Max Lederman]] – United States (1922–2018) Nobel laureate
*[[Benjamin Lee (physicist)|Benjamin Lee]] – Korea, United States (1935–1977)
*[[David Lee (physicist)|David Lee]] – United States (born 1931) Nobel laureate
*[[Tsung-Dao Lee]] – China, United States (born 1926) Nobel laureate
*[[Anthony James Leggett]] – U.K., United States (born 1938) Nobel laureate
*[[Gottfried Wilhelm Leibniz]] – Germany (1646–1716)
*[[Robert B. Leighton]] – United States (1919–1997)
*[[Georges Lemaître]] – Belgium (1894–1966)
*[[Philipp Lenard]] – Hungary, Germany (1862–1947) Nobel laureate
*[[John Lennard-Jones]] – U.K. (1894–1954)
*[[John Leslie (physicist)|John Leslie]] – U.K. (1766–1832)
*[[Walter Lewin]] – Netherlands, United States (born 1936)
*[[Martin Lewis Perl]] – United States (1927–2014)
*[[Robert von Lieben]] – Austria-Hungary (1878–1913)
*[[Alfred-Marie Liénard]] – France (1869–1958)
*[[Evgeny Lifshitz]] – Soviet Union (1915–1985)
*[[David Lindley (physicist)|David Lindley]] – United States (born 1956)
*[[John Linsley]] – United States (1925–2002)
*[[Chris Lintott]] – U.K. (born 1980)
*[[Gabriel Jonas Lippmann]] – France, Luxemburg (1845–1921) Nobel laureate
*[[Antony Garrett Lisi]] – United States (born 1968)
*[[Karl L. Littrow]] – Austria (1811–1877)
*[[Seth Lloyd]] – United States (born 1960)
*[[Oliver Lodge]] – U.K. (1851–1940)
*[[Maurice Loewy]] – Austria, France (1833–1907)
*[[Robert K. Logan]] – United States (born 1939)
*[[Mikhail Lomonosov]] – Denisovka (1711–1765)
*[[Alfred Lee Loomis]] – United States (1887–1975)
*[[Ramón E. López]] – United States (born 1959)
*[[Hendrik Lorentz]] – Netherlands (1853–1928) Nobel laureate
*[[Ludvig Lorenz]] – Denmark (1829–1891)
*[[Johann Josef Loschmidt]] – Austria (1821–1895)
*[[Oleg Losev]] – Tver (1903–1942)
*[[Archibald Low]] – U.K. (1888–1956)
*[[Per-Olov Löwdin]] – Sweden (1916–2000)
*[[Lucretius]] – Rome (98?–55BC)
*[[Aleksandr Mikhailovich Lyapunov]] – Imperial Russia (1857–1918)
*[[Joseph Lykken]] – United States (born 1957)
*[[Arthur B. McDonald]] – Canada (born 1943) Nobel laureate
*[[Carolina Henriette Mac Gillavry]] – Netherlands (1904–1993)
*[[Ernst Mach]] – Austria-Hungary (1838–1916)
*[[Ray Mackintosh]] – U.K. 
*[[Luciano Maiani]] – Italy, San Marino (born 1941)
*[[Theodore Maiman]] – United States (1927–2007)
*[[Arthur Maitland]] – U.K. (1925–1994)
*[[Ettore Majorana]] – Italy (1906–1938 presumed dead)
*[[Sudhansu Datta Majumdar]] – India (1915–1997)
*[[Richard Makinson]] – Australia (1913–1979)
*[[Juan Martín Maldacena]] – Argentina (born 1968)
*[[Étienne-Louis Malus]] – France (1775–1812)
*[[Leonid Isaakovich Mandelshtam]] – Imperial Russia, Soviet Union (1879–1944)
*[[Franz Mandl (physicist)|Franz Mandl]] – U.K. (1923–2009)
*[[Charles Lambert Manneback]] – Belgium (1894–1975)
*[[Peter Mansfield]] – U.K. (1933–2017)
*[[Carlo Marangoni]] – Italy (1840–1925)
*[[M. Cristina Marchetti]] – Italy, United States (born 1955)
*[[Guglielmo Marconi]] – Italy (1874–1937) Nobel laureate
*[[Henry Margenau]] – Germany, United States (1901–1977)
*[[Nina Marković]] – Croatia, United States 
*[[William Markowitz]] – United States (1907–1998)
*[[Robert Marshak]] – United States (1916–1992)
*[[Walter Marshall, Baron Marshall of Goring|Walter Marshall]] – U.K. (1932–1996)
*[[Toshihide Maskawa]] – Japan (1940–2021) Nobel laureate
*[[Harrie Massey]] – Australia (1908–1983)
*[[John C. Mather|John Cromwell Mather]] – United States (born 1946) Nobel laureate
*[[James Clerk Maxwell]] – U.K. (1831–1879)
*[[Brian May]] – U.K. (born 1947)
*[[Maria Goeppert Mayer]] – Germany, United States (1906–1972)
*[[Ronald E. McNair]] – United States (1950–1986)
*[[Simon van der Meer]] – Netherlands (1925–2011) Nobel laureate
*[[Lise Meitner]] – Austria (1878–1968)
*[[Fulvio Melia]] – United States (born 1956)
*[[Macedonio Melloni]] – Italy (1798–1854)
*[[Adrian Melott]] – United States (born 1947)
*[[Thomas Corwin Mendenhall]] – United States (1841–1924)
*[[Mambillikalathil Govind Kumar Menon|M. G. K. Menon]] – India (1928–2016)
*[[David Merritt]] – United States
*[[Albert Abraham Michelson]] – United States (1852–1931) Nobel laureate
*[[Arthur Alan Middleton]] – United States 
*[[Stanislav Mikheyev]] – Russia (1940–2011)
*[[Robert Millikan|Robert Andrews Millikan]] – United States (1868–1953) Nobel laureate
*[[Arthur Milne]] – U.K. (1896–1950)
*[[Shiraz Minwalla]] – India (born 1972)
*[[Rabindra Mohapatra|Rabindra Nath Mohapatra]] – India, United States (born 1944)
*[[Kathryn Moler]] – United States
*[[Merritt Moore]] – United States (born 1988)
*[[Tanya Monro]] – Australia (born 1973)
*[[John J. Montgomery]] – United States (1858–1911)
*[[Jagadeesh Moodera]] – India, United States (born 1950)
*[[Henry Moseley]] – U.K. (1887–1915)
*[[Rudolf Mössbauer]] – Germany (1929–2011) Nobel laureate
*[[Nevill Mott]] – U.K. (1905–1996) Nobel laureate
*[[Ben Roy Mottelson]] – Denmark, United States (born 1926) Nobel laureate
*[[Amédée Mouchez]] – Spain, France (1821–1892)
*[[Moustafa Mosharafa|Ali Moustafa]] – Egypt (1898–1950)
*[[José Enrique Moyal]] – Palestine, France, U.K., United States, Australia (1910–1998)
*[[Karl Alexander Müller]] – Switzerland (born 1927) Nobel laureate
*[[Richard A. Muller]] – United States (born 1944)
*[[Robert S. Mulliken]] – United States (1896–1986)
*[[Pieter van Musschenbroek]] – Netherlands (1692–1762)
*[[Yoichiro Nambu]] – Japan, United States (1921–2015) Nobel laureate
*[[Meenakshi Narain]] - experimental physicist, Professor of Physics at Brown University
*[[Jayant Narlikar]] – India (born 1938)
*[[Seth Neddermeyer]] – United States (1907–1988)
*[[Louis Néel]] – France (1904–2000) Nobel laureate
*[[Yuval Ne'eman]] – Israel (1925–2006)
*[[Ann Nelson]] – United States (1958–2019)
*[[John von Neumann]] – Austria-Hungary, United States (1903–1957)
*[[Simon Newcomb]] – United States (1835–1909)
*[[Sir Isaac Newton]] – England (1642–1727)
*[[Edward P. Ney]] – United States (1920–1996)
*[[Kendal Nezan]] – France, Kurdistan (born 1949)
*[[Holger Bech Nielsen]] – Denmark (born 1941)
*[[Leopoldo Nobili]] – Italy (1784–1835)
*[[Emmy Noether]] – Germany (1882–1935)
*[[Lothar Nordheim]] – Germany (1899–1985)
*[[Gunnar Nordström]] – Finland (1881–1923)
*[[Johann Gottlieb Nörremberg]] – Germany (1787–1862)
*[[Konstantin Novoselov]] – Soviet Union, U.K. (born 1974) Nobel laureate
*[[H. Pierre Noyes]] – United States (1923–2016)
*[[John Nye (scientist)|John Nye]] – U.K. (1923–2019)
*[[Yuri Oganessian]] – Russia (born 1933)
*[[Georg Ohm]] – Germany (1789–1854)
*[[Hideo Ohno]] – Japan (born 1954)
*[[Susumu Okubo]] – Japan, United States (1930–2015)
*Sir [[Mark Oliphant]] – Australia (1901–2000)
*[[David Olive]] – U.K. (1937–2012)
*[[Gerard K. O'Neill]] – United States (1927–1992)
*[[Lars Onsager]] – Norway (1903–1976)
*[[Robert Oppenheimer]] – United States (1904–1967)
*[[Nicole Oresme]] – France (1325–1382)
*[[Yuri Feodorovich Orlov|Yuri Orlov]] – Soviet Union, United States (born 1924)
*[[Leonard Salomon Ornstein]] – Netherlands (1880–1941)
*[[Egon Orowan]] – Austria-Hungary, United States (1901–1989)
*[[Hans Christian Ørsted]] – Denmark (1777–1851)
*[[Douglas D. Osheroff|Douglas Dean Osheroff]] – United States (born 1945) Nobel laureate
*[[Mikhail Vasilievich Ostrogradsky]] – Russia (1801–1862)
*[[Thanu Padmanabhan]] – India (born 1957)
*[[Heinz Pagels]] – United States (1939–1988)
*[[Abraham Pais]] – Netherlands, United States (1918–2000)
*[[Wolfgang K. H. Panofsky]] – Germany, United States (1919–2007)
*[[Blaise Pascal]] – France (1623–1662)
*[[John Pasta]] – United States (1918–1984)
*[[Jogesh Pati]] – United States (born 1937)
*[[Petr Paucek]] – United States
*[[Stephen Paul (physicist)|Stephen Paul]] – United States (1953–2012)
*[[Wolfgang Paul]] – Germany (1913–1993) Nobel laureate
*[[Wolfgang Pauli]] – Austria-Hungary (1900–1958) Nobel laureate
*[[Ruby Payne-Scott]] – Australia (1912-1981)
*[[George B. Pegram]] – United States (1876–1958)
*[[Rudolf Peierls]] – Germany, U.K. (1907–1995)
*[[Jean Charles Athanase Peltier|Jean Peltier]] – France (1785–1845)
*[[Roger Penrose]], mathematician – U.K. (born 1931) Wolf laureate
*[[Arno Allan Penzias]], electrical engineer – U.S.A. (born 1933) Nobel laureate
*[[Martin Lewis Perl]] – United States (1927–2014) Nobel laureate
*[[Saul Perlmutter]] – United States (born 1959) Nobel laureate
*[[Jean Baptiste Perrin]] – France (1870–1942) Nobel laureate
*[[Konstantin Petrzhak]] – Soviet Union, Russia (1907–1998)
*[[Bernhard Philberth]] – Germany (1927–2010)
*[[William Daniel Phillips]] – United States (born 1948) Nobel laureate
*[[Max Planck]] – Germany (1858–1947) Nobel laureate
*[[Joseph Plateau]] – Belgium (1801–1883)
*[[Milton S. Plesset]] – United States (1908–1991)
*[[Ward Plummer]] – United States (born 1940)
*[[Boris Podolsky]] – Taganrog (1896–1966)
*[[Henri Poincaré]], mathematician – France (1854–1912)
*[[Eric Poisson]] – Canada (born 1965)
*[[Siméon Denis Poisson]] – France (1781–1840) mathematician
*[[Balthasar van der Pol]] – Netherlands (1889–1959) electrical engineer
*[[Joseph Polchinski]] – United States (1954–2018)
*[[Hugh David Politzer]] – United States (born 1949) Nobel laureate
*[[John Polkinghorne]] – U.K. (born 1930)
*[[Alexander M. Polyakov]] – Russia, United States (born 1945)
*[[Bruno Pontecorvo]] – Italy, Soviet Union (1913–1993)
*[[Heraclides Ponticus]] – Greece (387–312 BC)
*[[Heinz Pose]] – Germany (1905–1975)
*[[Cecil Frank Powell]] – U.K. (1903–1969) Nobel laureate
*[[John Henry Poynting]] – U.K. (1852–1914)
*[[Ludwig Prandtl]] – Germany (1875–1953)
*[[Willibald Peter Prasthofer]] – Austria (1917–1993)
*[[Ilya Prigogine]] – Belgium (1917–2003)
*[[Alexander Prokhorov]] – Soviet, Russian (1916–2002) Nobel laureate
*[[William Prout]] – U.K. (1785–1850)
*[[Luigi Puccianti]] – Italy (1875–1952)
*[[Ivan Pulyuy]] – Ukraine (1845–1918)
*[[Mihajlo Idvorski Pupin]] – Serbia, United States (1858–1935)
*[[Edward Mills Purcell]] – United States (1912–1997) Nobel laureate
*[[Helen Quinn]] – Australia, United States (born 1943)
*[[Raúl Rabadán]] – United States
*[[Gabriele Rabel]] – Austria, United Kingdom (1880–1963)
*[[Isidor Isaac Rabi]] – Austria, United States (1898–1988) Nobel laureate
*[[Giulio Racah]] – Italian-Israeli (1909–1965)
*[[James Rainwater]] – United States (1917–1986) Nobel laureate
*[[Mark G. Raizen]] – New York City United States (born 1955)
*[[Alladi Ramakrishnan]] – India (1923–2008)
*[[Chandrasekhara Venkata Raman]] – India (1888–1970) Nobel laureate
*[[Edward Ramberg]] – United States (1907–1995)
*[[Carl Ramsauer]] – Germany (1879–1955)
*[[Norman Foster Ramsey, Jr.]] – United States (1915–2011) Nobel laureate
*[[Lisa Randall]] – United States (born 1962)
*[[Riccardo Rattazzi]] – Italy (born 1964)
*[[Lord Rayleigh]] – U.K. (1842–1919) Nobel laureate
*[[René Antoine Ferchault de Réaumur]] – France (1683–1757)
*[[Sidney Redner]] – Canada, United States (born 1951)
*[[Martin Rees, Baron Rees of Ludlow|Martin John Rees]] – U.K. (born 1942)
*[[Hubert Reeves]] – Canada (born 1932)
*[[Tullio Regge]] – Italy (1931–2014)
*[[Frederick Reines]] – United States (1918–1998) Nobel laureate
*[[Louis Rendu]] – France (1789–1859)
*[[Osborne Reynolds]] – U.K. (1842–1912)
*[[Owen Willans Richardson]] – U.K. (1879–1959) Nobel laureate
*[[Robert Coleman Richardson]] – United States (1937–2013) Nobel laureate
*[[Burton Richter]] – United States (1931–2018) Nobel laureate
*[[Floyd K. Richtmyer]] – United States (1881–1939)
*[[Robert D. Richtmyer]] – (1910–2003)
*[[Charlotte Riefenstahl]] – Germany (1899–1993)
*[[Nikolaus Riehl]] – Germany (1901–1990)
*[[Adam Riess]] – United States (born 1969) Nobel laureate
*[[Karl-Heinrich Riewe]] – Germany
*[[Walther Ritz]] – Switzerland (1878–1909)
*[[Étienne-Gaspard Robert]] – Belgium (1763–1837)
*[[Heinrich Rohrer]] – Switzerland (1933–2013) Nobel laureate
*[[Joseph Romm]] – United States (born 1960)
*[[Wilhelm Röntgen|Wilhelm Conrad Röntgen]] – Germany (1845–1923) Nobel laureate
*[[Clemens C. J. Roothaan]] – Netherlands (1918–2019)
*[[Nathan Rosen]] – United States, Israel (1909–1995)
*[[Marshall Rosenbluth]] – United States (1927–2003)
*[[Yasha Rosenfeld]] – Israel (1948–2002)
*[[Carl-Gustav Arvid Rossby]] – Sweden, United States (1898–1957)
*[[Bruno Rossi]] – Italy, United States (1905–1993)
*[[Joseph Rotblat]] – Poland, U.K. (1908–2005)
*[[Carlo Rovelli]] – Italy (born 1956)
*[[Subrata Roy (scientist)]] – India, United States
*[[Carlo Rubbia]] – Italy (born 1934) Nobel laureate
*[[Vera Rubin]] – United States (1928–2016)
*[[Serge Rudaz]] – Canada, United States (born 1954)
*[[David Ruelle]] – Belgium, France (born 1935)
*[[Ernst Ruska|Ernst August Friedrich Ruska]] – Germany (1906–1988) Nobel laureate
*[[Ernest Rutherford]] – New Zealand, U.K. (1871–1937)
*[[Johannes Rydberg|Janne Rydberg]] – Sweden (1854–1919)
*[[Martin Ryle]] – U.K. (1918–1984) Nobel laureate
*[[Mendel Sachs]] – United States (1927–2012)
*[[Rainer K. Sachs]] – Germany and United States (1932- )
*[[Robert G. Sachs]] – United States (1916–1999)
*[[Carl Sagan]] – United States (1934–1996)
*[[Georges-Louis Le Sage|Georges-Louis le Sage]] – Switzerland (1724–1803)
*[[Georges Sagnac]] – France (1869–1926)
*[[Megh Nad Saha]] – Bengali India (1893–1956)
*[[Shoichi Sakata]] – Japan (1911–1970)
*[[Andrei Sakharov|Andrei Dmitrievich Sakharov]] – Soviet Union (1929–1989)
*[[Oscar Sala]] – Brazil (1922–2010)
*[[Abdus Salam]] – Pakistan (1926–1996) Nobel laureate
*[[Edwin Ernest Salpeter]] – Austria, Australia, United States (1924–2008)
*[[Anthony Ichiro Sanda]] – Japan, United States (born 1944)
*[[Antonella De Santo]] – Italy, U.K.
*[[Vikram Sarabhai]] – India (1919–1971)
*[[Isidor Sauers]] – Austria (born 1948)
*[[Félix Savart]] – France (1791–1841)
*[[Brendan Scaife]] – Ireland (born 1928)
*[[Martin Schadt]] – Switzerland (born 1938)
*[[Arthur Leonard Schawlow]] – United States (1921–1999) Nobel laureate
*[[Craige Schensted]] – United States
*[[Joël Scherk]] – France (1946–1979)
*[[Otto Scherzer]] – Germany (1909–1982)
*[[Brian Schmidt]] – Australia, United States (born 1967) Nobel laureate
*[[Alan Schoen]] – United States (born 1924) 
*[[Walter H. Schottky]] – Germany (1886–1976)
*[[Kees A. Schouhamer Immink]] – Netherlands (born 1946)
*[[John Robert Schrieffer]] – United States (1931–2019) Nobel laureate
*[[Erwin Schrödinger]] – Austria-Hungary (1887–1961) Nobel laureate
*[[John Henry Schwarz]] – United States (born 1941)
*[[Melvin Schwartz]] – United States (1932–2006) Nobel laureate
*[[Karl Schwarzschild]] – German Empire (1876–1916)
*[[Julian Schwinger]] – United States (1918–1994) Nobel laureate
*[[Marlan Scully]] – United States (born 1939)
*[[Dennis William Sciama]] – U.K. (1926–1999)
*[[Bice Sechi-Zorn]] – Italy, United States (1928–1984)
*[[Thomas Johann Seebeck]] – Estonia (1770–1831)
*[[Raymond Seeger]] – United States (1906–1992)
*[[Emilio G. Segre]] – Italy, United States (1905–1989) Nobel laureate
*[[Nathan Seiberg]] – United States (born 1956)
*[[Frederick Seitz]] – United States (1911–2008)
*[[Nikolay Semyonov]] – Russia (1896–1986)
*[[Ashoke Sen]] – India (born 1956)
*[[Hiranmay Sen Gupta]] – Bangladesh (born 1934)
*[[Robert Serber]] – United States (1909–1997)
*[[Roman U. Sexl]] – Austria (1939–1986)
*[[Shen Kuo]] – China (1031–1095)&lt;!--NOTE: Shen is his family name--&gt;
*[[Mikhail Shifman]] – Russia, United States (born 1949)
*[[Dmitry Shirkov]] – Russia (1928–2016)
*[[William Shockley]] – United States (1910–1989) Nobel laureate
*[[Boris Shraiman]] – United States (1956)
*[[Lev Shubnikov]] – Russia, Netherlands, Ukraine (1901–1937)
*[[Clifford Shull]] – United States (1915–2001) Nobel laureate
*[[Kai Siegbahn]] – Sweden (1918–2007) Nobel laureate
*[[Manne Siegbahn]] – Sweden (1886–1978) Nobel laureate
*[[Ludwik Silberstein]] – Poland, Germany, Italy, United States, Canada (1872–1948)
*[[Eva Silverstein]] – United States (born 1970)
*[[John Alexander Simpson]] – United States (1916–2000)
*[[Willem de Sitter]] – Netherlands (1872–1934)
*[[Uri Sivan]] – Israel (born 1955)
*[[Tamitha Skov]] - space weather physicist, researcher and public speaker
*[[G. V. Skrotskii]] – Russia (1915–1992)
*[[Francis G. Slack]] – United States (1897–1985)
*[[John C. Slater]] – United States (1900–1976)
*[[Louis Slotin]] – United States (1910–1946)
*[[Alexei Yuryevich Smirnov]] – Russia, Italy (born 1951)
*[[George E. Smith]] – United States (born 1930) Nobel laureate
*[[Lee Smolin]] – United States (born 1955)
*[[Marian Smoluchowski]] – Poland (1872–1917)
*[[George Smoot]] – United States (born 1945) Nobel laureate
*[[Willebrord Snell]] – Netherlands (1580–1626)
*[[Arsenij Sokolov]] – Russia (1910–1986)
*[[Arnold Sommerfeld]] – Germany (1868–1951)
*[[Bent Sørensen (physicist)|Bent Sørensen]] – Denmark (born 1941)
*[[Rafael Sorkin]] – United States (born 1945)
*[[Nicola Spaldin]] – United Kingdom (born 1969)
*[[Maria Spiropulu]] – Greece (born 1970)
*[[Henry Stapp]] – United States (born 1928)
*[[Johannes Stark]] – Germany (1874–1957) Nobel laureate
*[[Max Steenbeck]] – (1901–1981)
*[[Joseph Stefan]] – Austria-Hungary, Slovenia (1835–1893)
*[[Jack Steinberger]] – Germany, United States (1921–2020) Nobel laureate
*[[Paul J. Steinhardt]]  – United States (born 1952)
*[[Carl August Steinheil]] – Germany (1801–1870)
*[[George Sterman]] – United States (born 1946)
*[[Otto Stern]] – Germany (1888–1969) Nobel laureate
*[[Simon Stevin]] – Belgium, Netherlands (1548–1620)
*[[Thomas H. Stix]] – United States (1924–2001)
*[[George Gabriel Stokes]] – Ireland, U.K. (1819–1903)
*[[Aleksandr Stoletov]] – Russia (1839–1896)
*[[Donna Strickland]]  – Canada (born 1959) Nobel laureate
*[[Horst Ludwig Störmer]] – Germany (born 1949) Nobel laureate
*[[Leonard Strachan]] - United States, astrophysicist
*[[Andrew Strominger]] – United States (born 1955)
*[[Ernst Stueckelberg]] – Switzerland (1905–1984)
*[[George Sudarshan]] – India, United States (1931–2018)
*[[Rashid Sunyaev]] – USSR (born 1943)
*[[Oleg Sushkov]] – USSR, Australia (born 1950)
*[[Leonard Susskind]] – United States (born 1940)
*[[Joseph Swan]] – U.K. (1828–1914)
*[[Jean Henri van Swinden]] – Netherlands (1746–1823)
*[[Bertha Swirles]] – U.K. (1903–1999)
*[[Leo Szilard]] – Austria-Hungary, United States (1898–1964)
*[[Igor Yevgenyevich Tamm]] – Imperial Russia, Soviet Union (1895–1971) Nobel laureate
*[[Abraham H. Taub]] – United States (1911–1999)
*[[Martin Tajmar]] – Austria (born 1974)
*[[Geoffrey Ingram Taylor]] – U.K. (1886–1975)
*[[Joseph Hooton Taylor, Jr.]] – United States (born 1941) Nobel laureate
*[[Richard E. Taylor|Richard Edward Taylor]] – United States (1929–2018) Nobel laureate
*[[Max Tegmark]] – Sweden, United States (born 1967)
*[[Valentine Telegdi]] – Hungary, United States (1922–2006) Wolf laureate
*[[Edward Teller]] – Austria-Hungary, United States (1908–2003)
*[[Igor Ternov]] – Russia (1921–1996)
*[[George Paget Thomson]] – U.K. (1892–1975) Nobel laureate
*[[J. J. Thomson]] – U.K. (1856–1940) Nobel laureate
*[[William Thomson, 1st Baron Kelvin|William Thomson (Lord Kelvin)]] – Ireland, U.K. (1824–1907)
*[[Charles Thorn]] – United States (born 1946)
*[[Kip Stephen Thorne]] – United States (born 1940)
*[[Peter Adolf Thiessen]] – Germany (1899–1990)
*[[Samuel C. C. Ting|Samuel Chao Chung Ting]] – United States (born 1936) Nobel laureate
*[[Frank J. Tipler]] – United States (born 1947)
*[[Ernest William Titterton]] – U.K., Australia (1916–1990)
*[[Yoshinori Tokura]] – Japan (born 1954)
*[[Samuel Tolansky]] – U.K. (1907–1973)
*[[Baien Tomlin]] – U.K. (1905–1972)
*[[Sin-Itiro Tomonaga]] – Japan (1906–1979) Nobel laureate
*[[Lewi Tonks]] – United States (1897–1971)
*[[Akira Tonomura]] – Japan (1942–2012)
*[[Evangelista Torricelli]] – Italy (1608–1647)
*[[Yoji Totsuka]] – Japan (1942–2008)
*[[Bruno Touschek]] – Italy (1921–1978)
*[[Charles Townes]] – United States (1915–2015) Nobel laureate
*[[John Sealy Townsend|John Townsend]] – U.K. (1868–1957)
*[[Johann Georg Tralles]] – Germany (1763–1822)
*[[Sam Treiman]] – United States (1925–1999)
*[[Daniel C. Tsui|Daniel Chee Tsui]] – China, United States (born 1939) Nobel laureate
*[[Vipin Kumar Tripathi]] – India (born 1948)
*[[John J. Turin]] – United States (1913–1973)
*[[Neil Turok]] – South Africa (born 1958)
*[[Twersky#Twersky|Victor Twersky]] – United States (1923–1998)
*[[Sergei Tyablikov]] – Russia (1921–1968)
*[[John Tyndall]] – U.K. (1820–1893)
*[[Neil deGrasse Tyson]] – United States (born 1958)
*[[George Eugene Uhlenbeck]] – Netherlands, United States (1900–1988)
*[[Stanislaw Ulam]] – Poland, United States (1909–1984)
*[[Nikolay Umov]] – Russia (1846–1915)
*[[Juris Upatnieks]] – Latvia, United States (born 1936)
*[[Cumrun Vafa]] – Iran, United States (born 1960)
*[[Léon Van Hove]] – Belgium (1924–1990)
*[[Sergei Vavilov]] – Soviet Union (1891–1951)
*[[Vlatko Vedral]] – United Kingdom, Serbia (born 1971)
*[[Evgeny Velikhov]] – Russia (born 1935)
*[[Martinus J. G. Veltman]] – Netherlands, United States (1931–2021) Nobel laureate
*[[Gabriele Veneziano]] – Italy (born 1942)
*[[Giovanni Battista Venturi]] – Italy (1746–1822)
*[[Émile Verdet]] – France (1824–1866)
*[[Erik Verlinde]] – Netherlands (1962)
*[[Herman Verlinde]] – Netherlands (1962)
*[[Jean-Pierre Vigier]] – France (1920–2004)
*[[Gaetano Vignola]] – Italy 
*[[Anatoly Vlasov]] – Russia (1908–1975)
*[[John Hasbrouck van Vleck]] – United States (1899–1980) Nobel laureate
*[[Woldemar Voigt]] – Germany (1850–1919)
*[[Burchard de Volder]] – Netherlands (1643–1709)
*[[Max Volmer]] – Germany (1885–1965)
*[[Alessandro Volta]] – Italy (1745–1827)
*[[Wernher Von Braun]], aerospace engineer – Germany (1912–1977)
*[[Johannes Diderik van der Waals]] – Netherlands (1837–1923) Nobel laureate
*[[James Wait]] – Canada (1924–1998)
*[[Ludwig Waldmann]] – Germany (1913–1980)
*[[Alan_Walsh_(physicist)|Alan Walsh]] – U.K., Australia (1916–1988)
*[[Ernest Walton]] – Ireland (1903–1995) Nobel laureate
*[[Wang Dezhao|Dezhao Wang]] – China (1905–1998)
*[[Wang Enge|Enge Wang]] – China (born 1957)
*[[Wang Huanyu|Huanyu Wang]] – China (1954—2018)
*[[Kan-Chang Wang]] – China (1907–1998)
*[[Wang Pu (physicist)|Pu (Paul) Wang]] – China (1902–1969)
*[[Wang Zhuxi|Zhuxi Wang]] – China (1911–1983)
*[[Aaldert Wapstra]] – Netherlands (1923–2006)
*[[John Clive Ward]] – England, Australia (1924–2000)
*[[Gleb Wataghin]] – Ukraine, Italy, Brazil (1896–1986)
*[[John James Waterston]] – U.K. (1811–1883)
*[[Alan Andrew Watson]] – U.K. (born 1938)
*[[James Watt]] – U.K. (1736–1819)
*[[Denis Weaire]] – Ireland (born 1942)
*[[Colin Webb]] – U.K. (born 1937)
*[[Wilhelm Eduard Weber|Wilhelm Weber]] – Germany (1804–1891)
*[[Katherine Weimer]] – United States (1919–2000)
*[[Alvin Weinberg]] – United States (1915–2006)
*[[Steven Weinberg]] – United States (1933–2021) Nobel laureate
*[[Rainer Weiss]] – United States (born 1932) Nobel laureate
*[[Victor Frederick Weisskopf]] – Austria, United States (1908–2002)
*[[Carl Friedrich von Weizsäcker]] – Germany (1912–2007)
*[[Heinrich Welker]] – Germany (1912–1981)
*[[Gregor Wentzel]] – Germany (1898–1978)
*[[Paul Werbos]] – United States (born 1947)
*[[Peter Westervelt]] – United States (1919–2015)
*[[Hermann Weyl]] – Germany (1885–1955)
*[[Christof Wetterich]] – Germany (born 1952)
*[[John Archibald Wheeler]] – United States (1911–2008)
*[[Gian-Carlo Wick]] – Italy (1909–1992)
*[[Emil Wiechert]] – Prussia (1861–1928)
*[[Carl Wieman]] – United States (born 1951) Nobel laureate
*[[Wilhelm Wien]] – Germany (1864–1928) Nobel laureate
*[[Arthur Wightman]] – United States (1922–2013)
*[[Eugene Wigner]] – Austria-Hungary, United States (1902–1993) Nobel laureate
*[[Frank Wilczek]] – United States (born 1951) Nobel laureate
*[[Charles Thomson Rees Wilson]] – U.K. (1869–1959) Nobel laureate
*[[Christine Wilson (scientist)]] – Canadian-American physicist and astronomer
*[[Kenneth G. Wilson|Kenneth Geddes Wilson]] – United States (1936–2013) Nobel laureate
*[[Robert R. Wilson]] – United States (1914–2000) Nobel laureate
*[[Robert Woodrow Wilson]] – United States (born 1936)
*[[John R. Winckler]] – United States (1918–2001)
*[[David J. Wineland]] – United States (born 1944) Nobel laureate
*[[Karl Wirtz]] – Germany (1910–1994)
*[[Mark B. Wise]] – Canada, United States (born 1953)
*[[Edward Witten]] – United States (born 1951)
*[[Emil Wolf]] – Czechoslovakia, United States (1922–2018)
*[[Fred Alan Wolf]] – United States (born 1934)
*[[Lincoln Wolfenstein]] – United States (1923–2015)
*[[Stephen Wolfram]] – U.K. (born 1959)
*[[Ewald Wollny]] – Germany (1846–1901)
*[[Robert W. Wood]] – United States (1868–1955)
*[[Michael Woolfson]] – U.K. (1927–2019)
*[[Chien-Shiung Wu]] – United States (1912–1997)
* [[Basilis C. Xanthopoulos]] – Greece (1951–1990)
*[[Rosalyn Yalow]] – United States (1921–2011)
*[[Chen Ning Yang]] – China (born 1922) Nobel laureate
*[[Félix Ynduráin]] – Spain (born 1946)
*[[Francisco José Ynduráin]] – Spain (1940–2008)
*[[Kenneth Young (physicist)|Kenneth Young]] – United States, China (born 1947)
*[[Thomas Young (scientist)|Thomas Young]] – UK (1773–1829)
*[[Hideki Yukawa]] – Japan (1907–1981) Nobel laureate
*[[Jan Zaanen]] – Netherlands (born 1957)
*[[Daniel Zajfman]] – Israel (born 1959)
*[[Anthony Zee]] – United States (born 1945)
*[[Pieter Zeeman]] – Netherlands (1865–1943) Nobel laureate
*[[Ludwig Zehnder]] – Switzerland (1854–1949)
*[[Anton Zeilinger]] – Austria (born 1945)
*[[Yakov Borisovich Zel'dovich]] – Russia (1914–1987)
*[[John Zeleny]] – United States (1872–1951)
*[[Frits Zernike]] – Netherlands (1888–1960) Nobel laureate
*[[Antonino Zichichi]] – Italy (born 1929)
*[[Hans Ziegler (physicist)|Hans Ziegler]] – Switzerland, United States (1910–1985)
*[[Karl Zimmer]] – Germany (1911–1988)
*[[Peter Zoller]] – Austria (born 1952)
*[[Dmitry Zubarev]] – Russia (1917–1992)
*[[Bruno Zumino]] – Italy (1923–2014)
*[[Wojciech H. Zurek]] – Poland, United States (born 1951)
*[[Robert Zwanzig]] – United States (1928–2014)
*[[George Zweig]] – United States (born 1937)
*[[Barton Zwiebach]] – United States (born 1954)
